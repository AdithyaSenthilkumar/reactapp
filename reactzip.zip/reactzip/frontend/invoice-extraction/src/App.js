import React from 'react';
import './styles/globals.css'
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider, useAuth } from './contexts/AuthContext.js';
import Login from './components/Login.js';
import Dashboard from './components/Dashboard.js';
import Layout from './components/Layout.js';
import InvoiceUpload from './components/InvoiceUpload.js';
import InvoiceView from './components/InvoiceView.js';
import ApprovalQueue from './components/ApprovalQueue.js';

const PrivateRoute = ({ children }) => {
  const { isAuthenticated } = useAuth();
  return isAuthenticated ? children : <Navigate to="/login" />;
};

const App = () => {
  return (
    <AuthProvider>
      <BrowserRouter>
        <Routes>
          <Route path="/login" element={<Login />} />
          <Route
            path="/"
            element={
              <PrivateRoute>
                <Layout>
                  <Dashboard />
                </Layout>
              </PrivateRoute>
            }
          />
          <Route
            path="/upload"
            element={
              <PrivateRoute>
                <Layout>
                  <InvoiceUpload />
                </Layout>
              </PrivateRoute>
            }
          />
          <Route
            path="/view/:division/:id"
            element={
              <PrivateRoute>
                <Layout>
                  <InvoiceView />
                </Layout>
              </PrivateRoute>
            }
          />
          <Route
            path="/approval"
            element={
              <PrivateRoute>
                <Layout>
                  <ApprovalQueue />
                </Layout>
              </PrivateRoute>
            }
          />
        </Routes>
      </BrowserRouter>
    </AuthProvider>
  );
};

export default App;
